package com.example.ktproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import androidx.appcompat.widget.AppCompatEditText as AppCompatEditText1

class MainActivity : AppCompatActivity() {
    //variaveis globais usa lateinit
    lateinit var texto: TextView
    lateinit var botao1: Button
    lateinit var ratingBar: RatingBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        texto = findViewById(R.id.textView)
        botao1 = findViewById(R.id.botao)
        ratingBar = findViewById(R.id.ratingBar)


        ratingBar.setOnRatingBarChangeListener{ratingBar, rating, fromUser -> rating
           texto.text =""+rating
        }
        botao.setOnClickListener{
            Toast.makeText(applicationContext,"Valor selecionado = "+ ratingBar.rating,Toast.LENGTH_LONG).show()
        }
    }
}

/*
package com.example.ktproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.widget.AppCompatEditText as AppCompatEditText1

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button.setOnClickListener{it:View!
            textView.text = editText.text
        }
    }
}
*/